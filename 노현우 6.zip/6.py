from random import *
import turtle

house = turtle.Turtle()
house.penup()
house.goto(0,0)
house.forward(300)
house.pendown()
house.fillcolor("skyblue")
house.begin_fill()
house.forward(100)
house.left(90)
house.forward(100)
house.left(90)
house.forward(100)
house.left(90)
house.forward(100)
house.end_fill()
##지붕
house.fillcolor("royalblue")
house.begin_fill()
house.goto(300,100)
house.right(210)
house.forward(100)
house.right(120)
house.forward(100)
house.right(120)
house.forward(100)
house.end_fill()
##길
line = turtle.Turtle()
line.penup()
line.goto(-300,0)
line.pendown()
line.write('0')
line.goto(0,0)
line.write('50')
line.goto(300,0)
line.write('100')
##거북
t = turtle.Turtle(shape = "turtle")
t.penup
t.goto(-300,0)
t.pendown()
t.color("purple","pink")
t.penup()
##문자열
g = turtle.Turtle()
##제목문자열
t.write("씨큐브 코딩의 타자 게임!",True, font=("Arial", 20, "bold"))

##게임시작


##단어목록
fruit = ["apple", "banana", "strawberry", "watermelon", "mandarin",
         "peach", "grapes", "Orange", "pear", "Kiwi"]

  ##점수
score = 0
##범위
n = randint(5, 10)







































