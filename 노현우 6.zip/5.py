from random import *
a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
x = (choices(a, [50, 50, 50, 50, 50, 50, 25, 50, 50, 50], k = 3))
print(x)
if x.count(7) == 3 :
     print('Lucky!')
elif x.count(7) == 2 :
     print('Good~')
else :
     print('Soso.')
     
