from random import *
a = ['apple', 'banana', 'grape', 'kiwi']
print(choice(a))

a = [1, 2, 3, 4, 5]
print(choices(a, [1, 2, 1, 1, 5], k = 3))
