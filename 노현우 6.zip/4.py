import random
a = [0, 1, 2, 3, 4, 5]
x = random.choice(a)
if x == 0 :
     print('Loss!')
else :
     print('no.%d Spot!' % x)
