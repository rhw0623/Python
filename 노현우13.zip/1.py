def warning() :
     for _ in range(3) :
          print("Fire!")
warning()
