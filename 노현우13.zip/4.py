def f() :
     a = 10
     print(a)
f()
print(a)
