from random import *
def random_number() :
     print(random() + 10)
random_number()


