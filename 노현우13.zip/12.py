def point(n) :
     i = n.split(".")
     print(i[1])

n = input()
point(n)
