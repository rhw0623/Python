def season(n) :
     if 3 <= n and n <= 5 :
          print("spring")
     elif 6 <= n and n <= 8 :
          print("summer")
     elif 9 <= n and n <= 11:
          print("fall")
     elif n == 1 or 2 or 12 :
          print("winter")
     else :
          print("?")
n = int(input())
season(n)
