def func_abs(n):
     if n > 0:
          print(n)
     elif n < 0 :
          print(-1 * n)
     else :
          print("?")
n = int(input())
func_abs(n)
