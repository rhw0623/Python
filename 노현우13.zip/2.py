def two_times() :
     for i in range(1, 10) :
          print("2 * %d = %d " % (i, 2 * i))
two_times()
