from tkinter import *

pen_size = 10
pen_color = "black"

def paint(event):
     global pen_color
     global pen_size
     x1,y1 = event.x, event.y
     x2, y2 = x1 + 5, y1 +5
     canvas.create_line(x1, y1, x2, y2, width = pen_size , fill = pen_color)
     
def change_color(color) :
     global pen_color
     pen_color = color

def clear_canvas():
     canvas.delete("all")

def pensize_up():
     global pen_size
     pen_size += 5

def pensize_down():
     global pen_size
     pen_size -= 5

win = Tk()

canvas = Canvas(win,bg = "white", width = 500, height = 500)
white_btn = Button(win, text = "white", command = lambda : change_color("white"), bg= "white", width = 6)
black_btn = Button(win, text = "black", command = lambda : change_color("black"), bg= "black", fg = "white", width = 6)
blue_btn = Button(win, text = "blue", command = lambda : change_color("blue"), bg= "blue", fg = "white", width = 6)
green_btn = Button(win, text = "green", command = lambda : change_color("green"), bg= "green", fg = "white", width = 6)
yellow_btn = Button(win, text = "yellow", command = lambda : change_color("yellow"), bg= "yellow", width = 6)
red_btn = Button(win, text = "red", command = lambda : change_color("red"), bg= "red", fg = "white", width = 6)
plus_btn = Button(win, text = "+", command = pensize_up, bg= "white", width = 6)
minus_btn = Button(win, text = "-", command = pensize_down, bg= "white", width = 6)
clear_btn = Button(win, text = "clear", command = clear_canvas, bg= "white", width = 6)

canvas.grid(row = 0, column = 0, columnspan= 9)

white_btn.grid(row = 1, column = 0)
black_btn.grid(row = 1, column = 1)
blue_btn.grid(row = 1, column = 2)
green_btn.grid(row = 1, column = 3)
yellow_btn.grid(row = 1, column = 4)
red_btn.grid(row = 1, column = 5)
plus_btn.grid(row = 1, column = 6)
minus_btn.grid(row = 1, column = 7)
clear_btn.grid(row = 1, column = 8)

win.bind("<B1-Motion>",paint)
win.mainloop()

