n = 1
a = int(input())
while n <= 9 :
     print("%d * %d = %d" % (a, n, a * n))
     n += 1
