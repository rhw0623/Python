n = 1
while n <= 20 :
     if n % 10 == 3 or n % 10 == 6 or n % 10 == 9 :
          print('X', end = ' ')
     else :
          print(n, end =  ' ')
     n += 1
