import random
r = random.randint(1,100)
while (1) :
     a = int(input())
     if a < r :
          print(" Up ")
     elif a > r :
          print(" Down ")
     elif a == r :
          print("Correct")
          break
