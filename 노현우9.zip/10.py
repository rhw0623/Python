n = int(input())
for a in range (n, 51) :
     print(n, end = ' ')
     n += 1
  
