a= int(input())
for n in range(1, a+1) :
     print(n)
     n += 1
     
