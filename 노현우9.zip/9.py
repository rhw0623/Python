a = input()
for n in range (1, 6) :
     print(a,end = (''))
     
