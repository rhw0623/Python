aList = [1, 2, 3]
bList = [10, 100, 1000]
for a in aList :
         for b in bList :
               print(a * b, end = ' ')
         print()
