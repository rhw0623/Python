for n in range (1, 101) :
     if n % 2 == 0 :
          print(n)
     else :
          continue
     n += 1
