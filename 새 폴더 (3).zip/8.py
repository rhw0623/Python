a = int(input('월 : '))
if  1 <= a and 7 >= a :
     print('first half')
elif  7 <= a and a <= 12 :
     print('second half')
else :
     print('What?')
