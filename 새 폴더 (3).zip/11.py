import random
com = random.randint(1, 3)
user = int(input('1 : 가위, 2 : 바위, 3 : 보\n'))
if com == 1 :
     com = '가위'
elif com == 2 :
     com ='바위'
elif com == 3 :
     com ='보'
if user == 1 :
     user = '가위'
elif user == 2 :
     user ='바위'
elif user == 3 :
     user ='보'
print('com(%s) : USER(%s)' %(com, user))
if com == user :
     print('Draw')
elif com == '가위' and user == '바위' :
     print('User Wins!')
elif com == '바위' and user == '보' :
     print('User Wins!')
elif com == '보' and user =='가위' :
     print('User Wins!')
if com == '바위' and user =='가위' :
     print('Com Wins!')
elif com == '보' and user == '바위' :
     print('Com Wins!')
elif com == '가위' and user == '보' :
     print('Com Wins!')
     

     



