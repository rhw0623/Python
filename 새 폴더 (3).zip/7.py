a = input('성별 : ')
if a == ('M'):
     print('Man')
elif a == ('W') :
     print('Woman')
else :
     print('What?')
