a = int(input())
if a % 3  == 0 :
     print('EVEN')
else:
     print('ODD')
