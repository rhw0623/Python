case = ['Home work', 'Eating', 'sleeping']
if 'Home work' in case :
     print("I have to do homework.")
else :
     print("It's break time")
