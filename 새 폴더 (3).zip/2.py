score = int(input('score : '))
if score >= 60 :
     print('pass')
else :
      print('Fail')
