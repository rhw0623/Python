print("===== menu =====\n1. buger\n2. sandwitch\n3. Hot dog\n4. coke\n5. milk\n================")
a = int(input())
if a == 1 :
     print('Burger are not available')
elif a==2 or a==3 :
     print('What would you like to drink?')
elif a==4 :
     print('I like coke, too')
elif a==5 :
     print('Would you like hat or cold?')
