import random

com = random.randint(1, 2)
user = int(input('odd : 1, even : 2\n'))
if com == 1 :
     com = 'odd'
else :
     com ='even'
if user == 1 :
     user = 'odd'
else :
     user ='even'
print('com(%s) : USER(%s)' %(com, user))
if com == user :
      print('correct')
else :
     print('Incorrect')
