a = int(input('score : '))
if a >= 90 :
     print('A')
elif a >= 60 :
     print('B')
else :
     print('C')
