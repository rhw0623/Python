a = int(input())
b = int(input())
c = int(input())
print(a >= 140 and b >= 140 and c >= 140)
