def area(x) :
     a = x * x * 3.14
     return a
x = int(input())

print(area(x))
