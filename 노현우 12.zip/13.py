def a(x,y) :
     return x + y

def b(x,y) :
     return x - y

def c(x,y) :
     return x * y

def d(x,y) :
     return x / y

print("What do you want :")
print("1. +" , "2. -", "3. x", "4. /" ,sep = '\n')
n = int(input())

if n == 1 :
     x = int(input("x : "))
     y = int(input("y : "))
     a = a(x,y)
elif n == 2 :
     x = int(input("x : "))
     y = int(input("y : "))
     a = b(x,y)
elif n == 3 :
     x = int(input("x : "))
     y = int(input("y : "))
     a = c(x,y)
elif n == 4 :
     x = int(input("x : "))
     y = int(input("y : "))
     a = d(x,y)
print(a)
