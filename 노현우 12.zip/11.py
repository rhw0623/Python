def get_max(n) :
     s = 0
     for i in range(n) :
          num = int(input())
          if s < num :
               s = num
          else :
               s = s
     return s
n = int(input("Enter integer n :"))

print("max value :" , get_max(n))
