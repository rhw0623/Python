def number(x) :
     if x % 2 == 0 :
          return ("even")
     else :
          return("odd")
n = int(input())
print(number(n))
