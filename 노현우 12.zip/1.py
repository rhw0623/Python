import sys
sys.stdout.write("Hello world")
print("Hello world")
