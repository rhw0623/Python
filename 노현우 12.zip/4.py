def b(x, y):
     if x > y :
          return x
     else :
          return y
x = int(input())
y = int(input())

n = b(x, y)
print(n)
