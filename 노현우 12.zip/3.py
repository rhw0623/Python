def f(n) :
     n = 20
     return n
n = 10

f(n)
print(n)
n = f(n)
print(n)
