def square(x, y) :
     return x ** y

x = int(input())
y = int(input())

print(square(x, y))

