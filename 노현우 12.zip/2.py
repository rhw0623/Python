##def add(x, y) :
##     s = x + y
##     return s
result = add(10,20) + add(20, 30)
print(result)
