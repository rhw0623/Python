def plus(x) :
     if x > 0 :
          return True
     else :
          return False
x = int(input())

n = plus(x)
print(n)
