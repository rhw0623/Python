def get_sum(x,y) :
     s = 0
     for i in range(x, y + 1) :
          s += i 
     return s
x = int(input())
y = int(input())
print("%d부터 %d까지의 합은 %d입니다." % (x, y, get_sum(x,y)))
