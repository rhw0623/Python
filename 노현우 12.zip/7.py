def area(x, y) :
     a = x * y
     return a
x = int(input())
y = int(input())

print(area(x,y))
