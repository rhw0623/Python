t1 = 0
t2 = (1,)
t3 = (1, 2, 3)
t4 = (1, 2, (3,  4))
print(t1)
print(t2)
print(t3)
print(t4)
