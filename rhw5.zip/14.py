a = set(['a', 'b', 'c', 'c', 'd', 'e', 'a'])
print(a)
