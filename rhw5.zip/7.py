a = {'a' : 1, 'b' : 2, 'c' : 3, 'd' : 4}
print(a.keys())
print(a.values())
print(a.items())
a.clear()
print(a)
