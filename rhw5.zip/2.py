s1 = set([1, 2, 3])
s2 = set('apple')
print(s1)
print(s2)






