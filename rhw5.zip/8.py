a = {'name' : 'Minsu', 'adress' : 'seoul', 'phone' : '010-1234-1234'}
print(a.keys())
