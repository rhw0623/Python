d = {'a' : 1, 'b' : 2}
d['c'] = 3
del d['a']
print(d)
