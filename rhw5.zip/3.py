t1 = (1,)
t2 = (4, 5, 6)
print(t1 + t2)
print(t2 * 2)
print(t2[0])
print(t2[1 : 3])
del t2[0]
