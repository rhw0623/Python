a = {'plus' : ['더하기','장점'],'minus' : ['빼기','적자'],'multiply' : [' 곱하다','다양하다'],'division' : ['나누기','분열']}
a['square'] = '제곱'
a = a.items()
print(a)
