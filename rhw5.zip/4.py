d = {'name' : 'jane', 'name' : 'mason', 'age' : 12,  'number' : 123456}
print(d)
print(d["age"])
