f = open("anna.txt", "r")
data = f.readline()
print(data)
