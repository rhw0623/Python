f = open("example.txt", "a")
alphabet = ['A', 'B', 'C', 'D', 'E']
for c in alphabet :
     f.write(c)
f.close()
