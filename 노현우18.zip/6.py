class TV:
     def __init__(self,ch,vol):
          self.channel = ch;
          self.volume = vol;
          self.power = True
     def on_off(self):
          if self.power:
               self.power = False
               print("Turn off")
          else:
               self.power = True
               print("Turn on")
     def info(self):
          print("Power : ",self.power)
          print("Channel : ",self.channel)
          print("Volume : ",self.volume)
     def set_channel(self,ch):
          if self.power:
               self.channel = ch
          else :
               print("Turn off")
     def set_volume(self,vol):
          if self.power:
               self.volume = vol
          else :
               print("Turn off")
tv = TV("1","16")
tv.info()
tv.set_channel(8)
tv.on_off()
tv.on_off()





               




               
