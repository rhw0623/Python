class Car :
     model = "BMW"
     color = "white"

bmw = Car()
benz = Car()

benz.model = "Benz"
benz.color = "black"

print(bmw.model)
print(bmw.color)

print(benz.model)
print(benz.color)
