import turtle
turtle.shape("turtle")
turtle.circle(50)
turtle.done
