import turtle
t = turtle.Turtle()

t.forward(100)
t.setheading(270)
t.forward(100)
t.setheading(180)
t.forward(100)

t.home()

turtle.done()
