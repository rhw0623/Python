import turtle

t = turtle.Turtle()

t.forward(100)
t.left(90)
t.forward(100)
t.left(90)
t.forward(100)
t.left(90)
t.forward(100)

t.right(90)
t.forward(100)
t.right(60)
t.backward(100)
t.right(60)
t.forward(100)

turtle.done()
