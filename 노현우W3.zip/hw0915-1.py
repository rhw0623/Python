a = 1
print(a)
include<stdio.h>
int main ()
{
     print("1");
}
