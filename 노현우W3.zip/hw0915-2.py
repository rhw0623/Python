a = int(input("a 정수입력 : "))
b = int(input("b 정수입력 : "))
c = int(input("c 정수입력 : "))
print("세정수의 평균은 %0.2f입나다." % ((a+b+c)/3))
