import turtle

t = turtle.Turtle()
t.shape('turtle')

r = 50
t.circle(r)
t.goto(100, 0)

r = r+30
t.circle(r)
t.goto(200,0)

r = r+30
t.circle(r)
