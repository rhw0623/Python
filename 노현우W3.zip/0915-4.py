import turtle
t = turtle.Turtle()
t.goto(100,60)
t.goto(100,-60)
t.goto(-100,60)
t.goto(-100,-60)
t.goto(0,0)
turtle.done()
