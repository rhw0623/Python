import turtle
t = turtle.Turtle()
s = int(input())

t.forward(s)
t.right(90)
t.forward(s)
t.right(90)
t.forward(s)
t.right(90)
t.forward(s)
t.right(30)
t.forward(s)
t.right(120)
t.forward(s)

turtle.done()
