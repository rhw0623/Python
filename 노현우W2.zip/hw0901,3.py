import turtle
turtle.shape("turtle")
turtle.circle(100)
turtle.circle(150)
turtle.circle(200)
turtle.done
