a = 'oh!my!god'
print(a.split('!'))
