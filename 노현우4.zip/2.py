a = 'I Love You'
print(a.count('o'))
print(a.find('Y'), a. index('Y'))
print('.'.join(a))
print(a.split())
print(a.replace('LOVE','like'))
print(a.upper(), a.lower())
