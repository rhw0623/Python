a = '간장공장공장장'
b = a.count('공장')
c = a.index('공장')
print(b)
print(c)
