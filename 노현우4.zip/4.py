a = [1, 5, 10, 3]
a.append(20)
print(a)
a.sort()
print(a)
a = ['b', 'a', 'n', 'a', 'n', 'a']
a.reverse()
print(a)
a.remove('a')
print(a)
p = a.pop()
print(p, a)
n = a.count('n')
print(n)
         
