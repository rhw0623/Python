a = ['c', 'e', 'a', 'd', 'b']
a.sort()
a.remove('e')
print(a)
