a = []
b = input('1 : ')
c = input('2 : ')
d = input('3 : ')
a.append(b)
a.append(c)
a.append(d)
print(b)
print(c)
print(d)
print(a)

