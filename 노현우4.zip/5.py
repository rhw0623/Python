num = input('주민번호 : ')
a = num[0:6]
b = num[7]
c = num[2:4]
d = num[4:6]
if(b == 1 or b ==3):
     b = '남자'
else:
     b = '여자'
print('생년월일 : %s' % a)
print('성별 : %s' % b)
print('생일 : %s월%s일'% (c,d))
