i = 0
for i in range(1, 11) :
     a = int(input())
     if i < a :
          i = a
     elif a > i :
          i = i
print(i)
