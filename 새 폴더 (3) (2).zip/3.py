n = int(input("정수를 입력하세요."))
sum = 0
for i in range(1, n + 1):
     if i % 3 == 0 :
          sum = sum + i

print(sum)


