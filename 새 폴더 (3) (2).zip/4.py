sum = 0
for i in range(1, 11):
     n = int(input("정수를 입력하세요."))
     if  sum < n :
          sum = n
     elif sum > n:
          sum = sum
     else :
          sum = sum

print(sum)
