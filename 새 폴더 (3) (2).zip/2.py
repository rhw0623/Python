from tkinter import *

def move_up(event) :
     global x, y
     y -= 20
     canvas.coords(racket, x, y)

def move_down(event) :
     global x, y
     y += 20
     canvas.coords(racket, x, y)

x, y = 400, 235

win = Tk()
canvas = Canvas(win, width = 500, height = 500, bg = "white")

img = PhotoImage(file = "red_racket.png")
racket = canvas.create_image(x, y, image = img)
canvas.pack()

win.bind("<Up>", move_up)
win.bind("<Down>", move_down)

win.mainloop()
