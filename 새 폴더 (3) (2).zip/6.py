import random
com = random.randint(1, 101)
while True:
     n = int(input(""))
     if com > n :
          print("Up")
     elif com < n :
          print("Down")
     else:
          print("Correct!")
          break
