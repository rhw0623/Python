while True :
     ans = input("Shall we dose? (y/n)")
     if ans == 'y' :
          print("The end")
          break
 
