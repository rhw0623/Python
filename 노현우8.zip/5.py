while True :
     ans = input("Are you ready? (yes/no)")
     if ans == 'yes' :
          print("going out")
          break
