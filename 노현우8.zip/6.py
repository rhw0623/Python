stamp = 0
while stamp < 10 :
     stamp += 1
     print("스템프%d개 적립" % stamp)
     if stamp == 10 :
          print("무료음료 쿠폰 1개 증정")
