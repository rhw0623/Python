sum = 0
i = 1
while i <= 100 :
     sum +1 = i
print(sum)
