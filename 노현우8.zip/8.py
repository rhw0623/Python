n = 1

while n <= 5 :
     n += 1
     a = int(input("input"))
     if a%5 == 0 :
          continue
     else :
          print("out put %d" % a)
     
