a = 1
while True :
     a = int(input("input"))
     if a == 0 :
          break
     
