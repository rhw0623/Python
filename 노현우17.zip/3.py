from PIL  import Image

size = (129,128)

fruit_img = Image.open("fruit.png")
fruit_rotated = fruit_img.rotate(270)
fruit_converted = fruit_img.convert('L')

fruit_converted.show()
fruit_rotated.show()
fruit_img.save("fruit_converted.png")
fruit_img.save("fruit_retated.png")
