from PIL  import Image

size = (129,128)

lion_img = Image.open("Lion.jpg")
lion_rotated = lion_img.rotate(90)
lion_converted = lion_img.convert('L')
lion_transpose = lion_img.transpose(Image.FLIP_LEFT_RIGHT)
lion_img.thumbnail(size)

print("lion_coverted.mode = ", lion_converted.mode)
print("lion_img.size = ", lion_img.size)

lion_rotated.show()
lion_converted.show()
lion_transpose.show()
lion_rotated.save("lion_rotated.jpg")
lion_img.save("lion_thumb.jpg")
