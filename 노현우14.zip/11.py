from tkinter import *

win = Tk()

def message(event):
     lbl['text'] = int(lbl ['text'] )+ int(entry.get())
     entry.delete(0, END)
def click():
     lbl['text'] = 0
btn = Button(win, text = "Clear",command = click)
entry = Entry(win)
entry.bind("<Return>", message)
lbl = Label(win, text = "0")
lbl.pack()
entry.pack()
btn.pack()
win.mainloop()
