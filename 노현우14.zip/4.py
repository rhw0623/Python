from tkinter import *

win = Tk()
label1 = Label(win, text = "orange", width = 20, height = 3, relief = "solid")
label2 = Label(win, text = "banana", font = ("Elephant", 20), bg = "yellow")
label3 = Label(win, text = "apple", fg = "red")
label1.pack()
label2.pack()
label3.pack()
win.mainloop()
