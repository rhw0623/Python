from tkinter import *

win = Tk()
img = PhotoImage(file = 'pizza.png')
lbl = Label(win, image = img)
lbl1 = Label(win, text = "Pizza",fg = "red", bg = "yellow")
lbl.pack()
lbl1.pack()
win.mainloop()
