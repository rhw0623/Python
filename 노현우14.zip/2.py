from tkinter import *

win = Tk()
win.title("C3 coding")
win.geometry("300x200+100+100")
win.resizable(True, False)
win.mainloop()
