from tkinter import *

win = Tk()
btn = Button(win, text = "Button")
btn.pack()
win.mainloop()
