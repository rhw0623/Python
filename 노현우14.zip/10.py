from tkinter import *
win = Tk()


def click() :
     if lbl1['text'] == "Hello" :
          lbl1['text'] = "Python"
          lbl1['bg'] = 'green'
     else :
          lbl1["text"] = "Hello"
          lbl1["bg"] = "orange"



lbl1 = Label(win, text = "Hello", bg = "orange")
btn = Button(win, text = "boutton",command = click)
lbl1.pack()
btn.pack()
win.mainloop()
