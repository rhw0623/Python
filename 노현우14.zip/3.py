from tkinter import *

win = Tk()
label1 = Label(win, text = "one")
label2 = Label(win, text = "two")
label3 = Label(win, text = "three")
label1.pack()
label2.pack()
label3.pack()
win.mainloop()
