from tkinter import *

def Click(n) :
     if n == "circle" :
          img = PhotoImage(file = "circle.png")
     elif n == "triangle" :
          img = PhotoImage(file = "triangle.png")
     else :
          img = PhotoImage(file = "star.png")
     lbl['image'] = img
     lbl.image = img


win = Tk()

img = PhotoImage(file = "circle.png")
lbl = Label(win, image = img)

btn1 = Button(win, text = "circle", command = lambda : Click("circle"))
btn2 = Button(win, text = "triangel", command = lambda : Click("triangle"))
btn3 = Button(win, text = "star", command = lambda : Click("star"))

lbl. grid(row = 0, column = 0, columnspan = 3)
btn1. grid(row = 1, column = 0)
btn2. grid(row = 1, column = 1)
btn3. grid(row = 1, column = 2)

win.mainloop()
