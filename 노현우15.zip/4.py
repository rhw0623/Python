say = lambda name : print("Hello" + name)
say(input())
