add = lambda x , y : x + y
print(add(100, 10))
