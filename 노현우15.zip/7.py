from tkinter import *
from random import *

win = Tk()

win.title("rock scissors paper Game")

basic_img = PhotoImage(file = "ready.png")

lbl_com = Label(win, image = basic_img, relief = "solid")
lbl_user = Label(win, image = basic_img, relief = "solid")

lbl_res = Label(win, text = " ", width = 15, bg = "lightyellow", fg = "red")

lbl_name1 = Label(win, text = "Computer")
lbl_name2 = Label(win, text = "user")

btn_scissor = Button(win, text = "scissor",command = lambda : change_img(0))
btn_rock = Button(win, text = "rock" ,command = lambda : change_img(1))
btn_paper = Button(win, text = "paper" ,command = lambda : change_img(2))

lbl_com.grid(row = 0, column = 0)
lbl_res.grid(row = 0, column = 1)
lbl_user.grid(row = 0, column = 2)

lbl_name1.grid(row = 1, column = 0)
lbl_name2.grid(row = 1, column = 2)

btn_rock.grid(row = 2, column = 0)
btn_scissor.grid(row = 2, column = 1)
btn_paper.grid(row = 2, column = 2)

def change_img(user) :
     List = ["scissors.png", "rock.png", "paper.png"]

     com = randint(0, 2)

     com_img = Photolmage(file = List[com])
     user_img = Photolmage(file = List[user])

     lbl_com["image"] = com_img
     lbl_com.image = com_img
     lbl_user["image"] = user_img
     lbl_user.image = user_img

def game(com,user):
     if user == 0:
          if com == 0:
               lbl_res["text"] = "Draw"
          elif com == 1:
               lbl_res["text"] = "Computer Win!"
          else:
               lbl_res["text"] = "User win!"

     elif user == 1:
          if com == 0:
               lbl_res["text"] = "User win!"
          elif com == 1:
               lbl_res["text"] = "Draw"
          else:
               lbl_res["text"] = "Computer win!"

     else:
          if com == 0:
               lbl_res["text"] = "Computer win!"
          elif com == 1:
               lbl_res["text"] = "User win!"
          else:
               lbl_res["text"] = "Draw"
               
win.mainloop()


                   
