remains = lambda a , b : a % b
print(remains(int(input()), (int(input()))))
